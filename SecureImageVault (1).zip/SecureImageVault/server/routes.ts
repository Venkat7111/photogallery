import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import multer from "multer";
import { storage } from "./storage";

const upload = multer({
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  app.get("/api/images", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }

    const images = await storage.getImagesByUserId(req.user.id);
    res.json(images);
  });

  app.post("/api/images", upload.single("file"), async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }

    if (!req.file) {
      return res.status(400).send("No file uploaded");
    }

    const image = await storage.createImage(req.user.id, {
      filename: req.file.originalname,
      contentType: req.file.mimetype,
      data: `data:${req.file.mimetype};base64,${req.file.buffer.toString("base64")}`,
      password: req.body.password || null,
      createdAt: new Date().toISOString(),
    });

    res.status(201).json(image);
  });

  app.delete("/api/images/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.sendStatus(401);
    }

    const image = await storage.getImage(parseInt(req.params.id));
    if (!image) {
      return res.status(404).send("Image not found");
    }

    if (image.userId !== req.user.id) {
      return res.status(403).send("Not authorized to delete this image");
    }

    await storage.deleteImage(parseInt(req.params.id));
    res.sendStatus(200);
  });

  const httpServer = createServer(app);
  return httpServer;
}

import { User, InsertUser, Image, InsertImage } from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";
import { randomBytes } from "crypto";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByResetToken(token: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserPassword(userId: number, password: string): Promise<void>;
  setResetToken(userId: number): Promise<string>;

  getImage(id: number): Promise<Image | undefined>;
  getImagesByUserId(userId: number): Promise<Image[]>;
  createImage(userId: number, image: Omit<Image, "id" | "userId">): Promise<Image>;
  deleteImage(id: number): Promise<void>;
  verifyImagePassword(id: number, password: string): Promise<boolean>;

  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private images: Map<number, Image>;
  private currentUserId: number;
  private currentImageId: number;
  readonly sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.images = new Map();
    this.currentUserId = 1;
    this.currentImageId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByResetToken(token: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.resetToken === token && 
      user.resetTokenExpiry && 
      new Date(user.resetTokenExpiry) > new Date(),
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id, 
      resetToken: null, 
      resetTokenExpiry: null 
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserPassword(userId: number, password: string): Promise<void> {
    const user = await this.getUser(userId);
    if (user) {
      user.password = password;
      user.resetToken = null;
      user.resetTokenExpiry = null;
      this.users.set(userId, user);
    }
  }

  async setResetToken(userId: number): Promise<string> {
    const user = await this.getUser(userId);
    if (user) {
      const token = randomBytes(32).toString('hex');
      const expiry = new Date();
      expiry.setHours(expiry.getHours() + 1); // Token expires in 1 hour

      user.resetToken = token;
      user.resetTokenExpiry = expiry.toISOString();
      this.users.set(userId, user);
      return token;
    }
    throw new Error('User not found');
  }

  async getImage(id: number): Promise<Image | undefined> {
    return this.images.get(id);
  }

  async getImagesByUserId(userId: number): Promise<Image[]> {
    return Array.from(this.images.values()).filter(
      (image) => image.userId === userId,
    );
  }

  async createImage(
    userId: number,
    image: Omit<Image, "id" | "userId">,
  ): Promise<Image> {
    const id = this.currentImageId++;
    const newImage: Image = { ...image, id, userId };
    this.images.set(id, newImage);
    return newImage;
  }

  async deleteImage(id: number): Promise<void> {
    this.images.delete(id);
  }

  async verifyImagePassword(id: number, password: string): Promise<boolean> {
    const image = await this.getImage(id);
    if (!image) return false;
    if (!image.password) return true;
    return image.password === password;
  }
}

export const storage = new MemStorage();
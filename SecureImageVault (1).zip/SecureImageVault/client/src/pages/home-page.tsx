import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Image, insertImageSchema } from "@shared/schema";
import { useDropzone } from "react-dropzone";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Loader2, Upload, Lock, Trash2, LogOut, Image as ImageIcon } from "lucide-react";
import Masonry from "react-masonry-css";

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const [imagePassword, setImagePassword] = useState("");
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);

  const { data: images, isLoading } = useQuery<Image[]>({
    queryKey: ["/api/images"],
  });

  const uploadMutation = useMutation({
    mutationFn: async ({ file, password }: { file: File; password?: string }) => {
      const formData = new FormData();
      formData.append("file", file);
      if (password) formData.append("password", password);

      const res = await fetch("/api/images", {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      if (!res.ok) {
        throw new Error(await res.text());
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/images"] });
      setUploadDialogOpen(false);
      setImagePassword("");
      toast({
        title: "Success",
        description: "Image uploaded successfully",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (imageId: number) => {
      await apiRequest("DELETE", `/api/images/${imageId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/images"] });
      toast({
        title: "Success",
        description: "Image deleted successfully",
      });
    },
  });

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      "image/*": [".png", ".jpg", ".jpeg", ".gif"],
    },
    onDrop: (files) => {
      if (files.length > 0) {
        uploadMutation.mutate({
          file: files[0],
          password: imagePassword || undefined,
        });
      }
    },
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-background/95">
      <header className="border-b bg-background/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-purple-600 bg-clip-text text-transparent flex items-center gap-2">
            <ImageIcon className="h-6 w-6" />
            Secure Gallery
          </h1>
          <div className="flex items-center gap-6">
            <span className="text-muted-foreground">Welcome, {user?.username}</span>
            <Button
              variant="outline"
              onClick={() => logoutMutation.mutate()}
              disabled={logoutMutation.isPending}
              className="gap-2"
            >
              {logoutMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <LogOut className="h-4 w-4" />
              )}
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
            <DialogTrigger asChild>
              <Button size="lg" className="bg-gradient-to-r from-primary to-purple-600 hover:opacity-90">
                <Upload className="mr-2 h-5 w-5" />
                Upload Image
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Upload Image</DialogTitle>
              </DialogHeader>
              <div className="space-y-6 py-4">
                <div
                  {...getRootProps()}
                  className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer transition-all duration-300 ${
                    isDragActive ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
                  }`}
                >
                  <input {...getInputProps()} />
                  <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-lg font-medium">Drag & drop an image here</p>
                  <p className="text-sm text-muted-foreground mt-1">or click to select</p>
                </div>
                <div className="space-y-2">
                  <Input
                    type="password"
                    placeholder="Optional password protection"
                    value={imagePassword}
                    onChange={(e) => setImagePassword(e.target.value)}
                    className="h-11"
                  />
                  <p className="text-xs text-muted-foreground">
                    Leave blank for no password protection
                  </p>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center min-h-[400px]">
            <Loader2 className="h-12 w-12 animate-spin text-primary" />
          </div>
        ) : images?.length === 0 ? (
          <div className="text-center py-12">
            <ImageIcon className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <h2 className="text-xl font-semibold mb-2">No images yet</h2>
            <p className="text-muted-foreground">
              Start by uploading your first image
            </p>
          </div>
        ) : (
          <Masonry
            breakpointCols={{
              default: 4,
              1280: 3,
              1024: 2,
              640: 1,
            }}
            className="flex -ml-4 w-auto"
            columnClassName="pl-4 bg-clip-padding"
          >
            {images?.map((image) => (
              <div
                key={image.id}
                className="mb-4 group relative rounded-xl overflow-hidden ring-1 ring-black/5 hover:ring-primary/20 transition-all duration-300"
              >
                <img
                  src={image.data}
                  alt={image.filename}
                  className="w-full h-auto rounded-xl transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/0 to-black/0 opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-end justify-between p-4">
                  <div className="flex items-center gap-2">
                    {image.password && (
                      <Lock className="h-5 w-5 text-white" />
                    )}
                    <span className="text-white text-sm font-medium">
                      {image.filename}
                    </span>
                  </div>
                  <Button
                    variant="destructive"
                    size="icon"
                    className="opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    onClick={() => deleteMutation.mutate(image.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </Masonry>
        )}
      </main>
    </div>
  );
}